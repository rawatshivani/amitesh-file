from django.db import models

# Create your models here.

# class doctor(models.Model):
# 	name = models.charfield(max_length = 50)
	